//javascript
$(document).ready(function () {
    var theKeyword = null;
    //TODO - Move this out of button funciton
        var answerArray = ["money", "health", "love", "work", "life", "expensive", "concerned", "feel", "do"];
    var indexFrom = SetIndex();
    $("#theButton").click(function () {
        //reset keyword
        ResetKeyword();
        //take input, make lower case
        var answer = $("#textBox").val().toLowerCase();
        //for each word in answerArray, check if answer is in there inputArray
        //if it is, export the word out of the function
        for(var i = 0; i < answerArray.length; i++){
            if(answer.indexOf(answerArray[i], GetIndex().length) > -1) {
                SetWord(answerArray[i]);
                break;
            }
            else {
                console.log("We did not find the word in our for loop");
            }
        }   
        //check the word
        Response(GetWord());
    });
});
        
function GetWord(){
    return theKeyword;
}

function SetWord(word){
    theKeyword = word;
}

function ResetKeyword(){
    theKeyword = null;
}

function GetIndex(){
    return indexFrom;
}

function SetIndex() {
    indexFrom = $("#textBox").val().toLowerCase();
}

function Response(word){
    if(word == "money"){
        $("#output").html("We can never have enough money my friend, have you thought what this might affect?");
        //.prop changes the input value 
        $("#textBox").prop('value' , "It might affect my ");
        SetIndex();
    }
    else if (word == "health"){
        $("#output").html("All we ask for is good health, but it sadly comes at a steep cost here.  What do you think about when we talk about healthcare?");
        $("#textBox").prop('value' , "I think about ");
        SetIndex();
    }
    else if (word == "love"){
        $("#output").html("Some of us are in love, some of us are looking for love. Is there anything stopping you from being in love?");
        $("#textBox").prop('value' , "What is stopping me is ");
        SetIndex();
    }
    else if (word == "work"){
        $("#output").html("Be it school work, or your employment life, work can get in the way of a few things.  Why do you have to work?");
        $("#textBox").prop('value' , "It is because of ");
        SetIndex();
    }
    else if (word == "life"){
        $("#output").html("Well you can only play with the cards life hands you.  Is there another factor that makes you feel this way about life?");
        $("#textBox").prop('value' , "I feel this way because of ");
        SetIndex();
    }
    else if (word == "expensive"){
        $("#output").html("Living in Seattle is pretty expensive!  It seems the cost of living is only going to go up and up.  How will you cope with this?");
        $("#textBox").prop('value' , "I am going to ");
        SetIndex();
    }
    else if (word == "concerned"){
        $("#output").html("That does sound worrying, but I'm sure you'll pull through in the end.  Is there anything else that concerns you?");
        $("#textBox").prop('value' , "I am concerned about ");
        SetIndex();
    }
    else if (word == "feel"){
        $("#output").html("Those feelings are absolutely justified.  But look at the bright side of things, how else do you feel?");
        $("#textBox").prop('value' , "I feel that ");
        SetIndex();
    }
    else if (word == "do"){
        $("#output").html("Until you try, you never will know if you will succeed or not, maybe the best thing to do is just do it?  Does anything else stop you from doing that?");
        $("#textBox").prop('value' , "I have reservations about ");
        SetIndex();
    }
    else {
        $("#output").html("I wish I could help you with that problem, but is there anything else I can assist you with?");
        $("#textBox").prop('value' , "I am concerned about ");
        SetIndex();
    }
}